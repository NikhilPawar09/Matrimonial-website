from django.contrib import admin
from django.urls import path
from.import views

urlpatterns = [
    path('register/',views.register,name='register'),   
    path('home/',views.home,name='home'),
    path('admintb/',views.admintab,name='admintb'),
    path('religion/',views.religion,name='religion'),
    path('relupdate/<id>',views.relupdate,name='relupdate'),
    path('login/',views.login,name='login'),                
    path('country/',views.country,name='country'),
    path('countryupdate/<id>',views.countryupdate,name='countryupdate'),
    path('delcountry/<id>',views.delcountry,name='delcountry'),     
    path('',views.index,name='index'),
    path('penal/',views.penal,name='penal'),
    path('inner/',views.inner,name='inner'),
    path('registration/',views.registration,name='registration'),
    path('form/',views.form,name='form'),
    
    path('community/',views.community,name='community'),
    path('updatecommunity/<id>',views.updatecommunity,name='updatecommunity'),
    path('delcommunity/<id>',views.delcommunity,name='delcommunity'),
    path('subcommunity/',views.subcommunity,name='subcommunity'),
    path('delreligion/<id>',views.delreligion,name='delreligion'),
    # path('fortest/',views.fortest),
    path('upsubc/<id>',views.updatesubcommunity,name='updatesubcommunity'),
    path('delsc/<id>',views.delsc,name='delsc')
    
    
    
]