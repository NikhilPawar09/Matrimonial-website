from datetime import date
from django.conf.urls.static import static
from django.shortcuts import redirect,render,HttpResponse
from django.core.files.storage import FileSystemStorage
from django.db import connection


""" def fortest(request):
    if request.method=="POST":
        
        f1=request.POST.get('f')
        print(f1)
        l1=request.POST.get('l')
        print(l1)
        g1=request.POST.get('gender')
        print(g1)
        l2=request.POST.get('lookfor')
        print(l2)
        e1=request.POST.get('e')
        print(e1)
        d1=request.POST.get('d')
        print(d1)
        c1=connection.cursor()
        c1.execute("call sp_register('"+f1+"','"+l1+"','"+g1+"','"+l2+"','"+e1+"','"+d1+"')")
        c1.close()

        return render(request,'fortest.html') 
    return render(request,'fortest.html')
 """



def register(request):
    
    if request.method=="POST":
        
        f1=request.POST.get('f')
        print(f1)
        l1=request.POST.get('l')
        print(l1)
        g1=request.POST.get('gender')
        print(g1)
        l2=request.POST.get('lookfor')
        print(l2)
        e1=request.POST.get('e')
        print(e1)   
        d1=request.POST.get('d')
        print(d1)
        c1=connection.cursor()
        c1.execute("call sp_register('"+f1+"','"+l1+"','"+g1+"','"+l2+"','"+e1+"','"+d1+"')")

        c1.close()
        return render(request,'register.html') 
    return render(request,'register.html')      
                                    

def home(request):
    if request.method=='POST':
        return redirect('/register')
    return render(request,'home.html')


def index(request):
    
    return render(request,'index.html')



def registration(request):
    return render(request,'registration.html')
    
def penal(request):
    if request.method=='POST':
        un=request.POST.get('username')
        pa=request.POST.get('password')
        c=connection.cursor()
        c.execute("call sp_login('"+un+"','"+pa+"')")
        c.close()
        if c.rowcount > 0:
            return redirect('/inner')
        else:
            return render (request,'penal.html',{'msg':'Invalid User or Password'})
    return render(request,'penal.html')


def form(request):
    return render(request,'form.html')


    
def inner(request):
    return render(request,'inner.html')

def admintab(request):
    if request.method=='POST':
        un=request.POST.get('u1')
        pa=request.POST.get('p1')
       
        c=connection.cursor()
        c.execute("call sp_login('"+un+"','"+pa+"')")
        if c.rowcount > 0:
            return redirect('/inner')
        else:
            return render (request,'login.html',{'msg':'Invalid User or Password'})
            
    return render(request,'login.html')

def religion(request):

    if request.method=="POST":
        rn=request.POST.get('r')
        c=connection.cursor()
        c.execute("call sp_religion('"+rn+"')")
        c.close()
        # It is POST Method
        return render(request,'religion.html',{'list':showrel()})
    # it is GET Method
    return render(request,'religion.html',{'list':showrel()})
    


def showrel():
    c=connection.cursor()
    c.execute("call sp_religionshow()")        
    i=[]
    for item in c.fetchall():
        i.append({'id':item[0],'relname':item[1]})
    c.close()
    return i

def relupdate(request,id):
    if request.method=='POST':
        rn=request.POST.get('u')
        c=connection.cursor()
        c.execute("call sp_religionedit('"+id+"','"+rn+"')")
        print(rn,id)
        return redirect('/religion')
    else:
        c=connection.cursor()
        c.execute("call getrelnamebyid('"+id+"')")
        l=[]
        for item in c.fetchall():
            l.append({'id':item[0],'relname':item[1]})
        c.close()
        return render(request,'relupdate.html',{'list':l})
    

def delreligion(request,id):
    c=connection.cursor()
    c.execute("call sp_delrel('"+id+"')")
    c.close()
    return redirect('/religion') 

def login(request):
    if request.method=='POST':
        u=request.POST.get('u1')
        p=request.POST.get('p1')
        c=connection.cursor()
        c.execute("call sp_login('"+u+"','"+p+"')")
        c.close()

        return render(request,'index.html')
    return render(request,"login.html")

def country(request):
    if request.method=="POST":
        rn=request.POST.get('r')
        c=connection.cursor()
        c.execute("call sp_countryins('"+rn+"')")
        c.close()
        return render(request,'country.html',{'list':showcountry()})
    return render (request,'country.html',{'list':showcountry()})


def showcountry():
    c=connection.cursor()
    c.execute("call sp_countryshow()")
    
    l=[]
    for item in c.fetchall():
        l.append({'id':item[0],'cyname':item[1]})
    c.close()
    return l

def countryupdate(request,id):
    if request.method=="POST":
        rn=request.POST.get('r')
        c=connection.cursor()
        c.execute("call sp_countryupdate('"+id+"','"+rn+"')")
        c.close()
        return redirect('/country')
    else:
        c=connection.cursor()
        c.execute("call getCountryById('"+id+"')")
        l=[]
        for item in c.fetchall():
            l.append({'id':item[0],'cyname':item[1]})
        c.close()
        return render(request,'countryupdate.html',{'data':l}) 

def delcountry(request,id):
    c=connection.cursor()
    q='delete from countrytb where id=%s'
    t=(id,)
    c.execute(q,t)
    return redirect('/country')

'''def updaterel(request,id):
    if request.method=="POST":
        rn=request.POST.get('r')
        c=connection.cursor()
        c.execute("call sp_updaterel('"+id+"','"+rn+"')")
        c.close()
        return 
    return render(request,'updaterel.html')
    '''

def community(request):
    if request.method=="POST":
        cn=request.POST.get("cm")
        c=connection.cursor()
        c.execute("call sp_community('"+cn+"')")
        c.close() 
        return render(request,'community.html',{'list':showcommunity()})
    return render(request,'community.html',{'list':showcommunity()})


def showcommunity():
    c=connection.cursor()
    c.execute("call sp_showcommunity()")
    i=[]
    for item in c.fetchall():
        i.append({'id':item[0],'cname':item[1]})
    c.close()
    return i


def updatecommunity(request,id):
    if request.method=="POST":
        un=request.POST.get('u')
        c=connection.cursor()
        c.execute("call sp_updatecommunity('"+id+"','"+un+"')")
        print('pawar')
        c.close()
        return redirect ('/community')
    else:
        c=connection.cursor()
        c.execute("call getcomyid('"+id+"')")
        p=[]
        for item in c.fetchall():
            p.append({"id":item[0],"cname":item[1]})
        c.close()
        return render (request,'updatecommunity.html',{'list':p})
    

        
def delcommunity(request,id):
        c=connection.cursor()
        q='delete from community where id=%s'
        t=(id,)
        c.execute(q,t)
        c.close()
        return redirect('/community')

def subcommunity(request):
    if request.method=="POST":
        sn=request.POST.get('s')
        c=connection.cursor()
        c.execute("call sp_subcommunity('"+sn+"')")
        c.close()
        # It is POST Method
        return render(request,'subcommunity.html',{'list':showscm()})
    # it is GET Method
    return render(request,'subcommunity.html',{'list':showscm()})


def showscm():
    c=connection.cursor()
    c.execute("call sp_showscm()")
    l=[]
    for item in c.fetchall():
        l.append({'id':item[0],'scm':item[1]})
    c.close()
    return l

def updatesubcommunity(request,id):
    if request.method=="POST":
        name=request.POST.get('scname')
        w=connection.cursor()
        q='update subcommunity set subname=%s where id=%s'
        t=(name,id,)
        w.execute(q,t)
        w.close()
        return redirect('/subcommunity')
    else:
        w=connection.cursor()
        w.execute("call sp_scnamebyid('"+id+"')")
        
        p=[]
        for item in w.fetchall():
            p.append({"id":item[0],"cmname":item[1]})
        w.close()
        return render(request,'updatesubcommunity.html',{'list':p})
    
def delsc(request,id):
    c1=connection.cursor()
    q='delete from subcommunity where id=%s'
    t=(id,)
    c1.execute(q,t)
    return redirect ('/subcommunity')